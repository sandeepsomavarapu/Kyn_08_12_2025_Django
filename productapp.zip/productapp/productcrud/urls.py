

from django.urls import path
from . import views

urlpatterns = [
    path('',views.fetch_products),
    path('fetchall',views.fetch_products,name="fetchall"),
    path('saveproduct',views.insert),
    path('update/',views.update_product),
    path('delete/<int:id>',views.delete_product)
]