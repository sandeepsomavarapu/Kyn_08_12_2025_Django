from django.shortcuts import redirect, render
from django.http import HttpResponse
from .models import Product
# Create your views here.
#fetch products

def fetch_products(request):
    products=Product.objects.all() #select  * from pproductcrud.[product
    return render(request,'products.html',{'products':products})
def insert(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        price = request.POST.get('price')
        description = request.POST.get('description')
        category = request.POST.get('category')
        product = Product(name=name, price=price, description=description, category=category)
        product.save()#insert query
    return redirect(fetch_products)
def update_product(request):
    pass
def delete_product(request,id):
    Product.objects.get(id=id).delete()
    return redirect(fetch_products)