"""
URL configuration for productapp project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.urls import include
from . import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/', views.index,name="home"),
    path('',include('productcrud.urls')),
    path('api/',include('employeecrud.urls'))
]
#urls
#GET   /api/employees   -->list all employees
#GET   /api/employees/<id>-->get one emplpoyee
#POST  /api/employees/ -->create new employee
#PUT   /api/employees/<id>/-->full update of employee
#DELETE /api/employees/<id>/--Delete employee
#PATH /api/employees/<id>/--partial update