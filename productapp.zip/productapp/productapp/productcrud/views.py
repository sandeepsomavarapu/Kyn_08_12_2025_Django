from django.shortcuts import redirect, render, reverse, get_object_or_404
from django.http import HttpResponse
from .models import Product

# 1. Fetch Products (Unchanged)
def fetch_products(request):
    products = Product.objects.all()
    # The HTML you provided is a mix, but we assume it is rendered here
    return render(request, 'products.html', {'products': products})

# 2. Display the Blank Form for Adding (New View for Clarity)
def add_product(request):
    # This view only handles the GET request to display the blank form
    return render(request, 'addform.html')

# 3. Handle Form Submission (Both Add and Update POST to the correct URL)
def insert(request):
    if request.method == 'POST':
        # Your insertion logic remains here
        name = request.POST.get('name')
        price = request.POST.get('price')
        description = request.POST.get('description')
        category = request.POST.get('category')
        product = Product(name=name, price=price, description=description, category=category)
        product.save()
    
    # Redirect to the product list after creation
    return redirect(reverse('fetchall')) 

# 4. Update Product Logic (Handles GET for form and POST for submission)
def update_product(request, id):
    # Use get_object_or_404 for safer retrieval
    product = get_object_or_404(Product, pk=id)
    
    if request.method == 'POST':
        # Update fields using the existing product object
        product.name = request.POST.get('name')
        product.price = request.POST.get('price')
        product.description = request.POST.get('description')
        product.category = request.POST.get('category')
        product.save()
        
        # Redirect to the product list after update
        return redirect(reverse('fetchall')) 
    
    # GET request: Render the form, passing the product object to pre-fill fields
    return render(request, 'addform.html', {'product': product})

# 5. Delete Product (Unchanged)
def delete_product(request, id):
    get_object_or_404(Product, pk=id).delete()
    return redirect(reverse('fetchall'))