# productcrud/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.fetch_products),
    path('fetchall', views.fetch_products, name="fetchall"),
    path('addproduct/', views.add_product, name="add_product"),
    path('saveproduct', views.insert, name="save_product"), 
    path('update/<int:id>/', views.update_product, name="update"), 
    path('delete/<int:id>/', views.delete_product, name="delete"),
]