from django.shortcuts import render,get_object_or_404,redirect
from .models import Product, Customer, Order,Category
from django.contrib.auth.decorators import login_required
from django import forms
from datetime import datetime

# Create your views here.

def product_list(request):
    products=Product.objects.all()
    return render(request,'product_list.html',{'products':products})
def product_detail(request, pk):
    product=get_object_or_404(Product, pk=pk)
    return render(request, 'product_detail.html', {'product':product})

def get_cart(request):
    cart = request.session.get('cart', {})
    return cart
def add_to_cart(request, pk):
    product = get_object_or_404(Product, pk=pk)
    cart = get_cart(request)
    quantity = int(request.POST.get('quantity', 1))
    product_id = str(product.id)
    cart[product_id]=cart.get(product_id, 0) + quantity
    request.session['cart'] = cart
    request.session.modified = True
    return redirect('cart_detail')
def cart_detail(request):
    cart = get_cart(request)
    cart_items = []
    total_price = 0
    for product_id, quantity in cart.items():
        product = get_object_or_404(Product, pk=product_id)
        cart_items.append({'product': product, 'quantity': quantity})
        total_price += product.price * quantity
    return render(request, 'cart_detail.html', {'cart_items': cart_items, 'total_price': total_price})
 
def remove_from_cart(request, pk):
    cart = get_cart(request)
    product_id = str(pk)
    if product_id in cart:
        del cart[product_id]
        request.session['cart'] = cart
        request.session.modified = True
    return redirect('cart_detail')

class CheckoutForm(forms.Form):
    name = forms.CharField(max_length=100)
    email = forms.EmailField()
def checkout(request):
    cart = get_cart(request)
    if not cart:
        return redirect('product_list')
    if request.method == 'POST':
        form = CheckoutForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            customer, created = Customer.objects.get_or_create(name=name, email=email)
            for product_id, quantity in cart.items():
                product = get_object_or_404(Product, pk=product_id)
                total = product.price * quantity
                status = 'Pending'
                date= datetime.now()
                order = Order(product=product, customer=customer, quantity=quantity, total=total, status=status, date=date)
                order.save()
            request.session['cart'] = {}
            request.session.modified = True
            return redirect('order_confirmation')
    else:
        form = CheckoutForm()
    return render(request, 'checkout.html', {'form': form})    
def order_confirmation(request):
    return render(request, 'order_confirmation.html')