
# Functions Example
def sumAndAverage(x, y, z):
    Sum = x + y + z
    Average = Sum/3
    print("\n %d is the Total Sum of three Numbers." %Sum,Average)
    print("\n %d is the Average of three Numbers.\n" %Average)
    
# Allows User to enter three values
a = int(input("\nPlease Enter the First Value. a =  "))
b = int(input("\nPlease Enter the Second Value. b =  "))
c = int(input("\nPlease Enter the Third Value. c =  "))

# Calling the Function
sumAndAverage(a, b, c)
sumAndAverage(10, 20, 30)#static

#login

