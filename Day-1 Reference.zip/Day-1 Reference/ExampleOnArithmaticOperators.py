a=int(input('enter the value for a'))
b=int(input('enter the value for b'))

res=a+b;
print('addition of two numbers',res)

res1=a-b
print('substractions : ',res1);

res2=a*b
print('multiplication : ',res2)

res3=a**b 
print('power of a is ',res3)

res4=a/b  #return float value
print ('division of number is ',res4);

res5=a//b # it will return floor value 
print(res5)


