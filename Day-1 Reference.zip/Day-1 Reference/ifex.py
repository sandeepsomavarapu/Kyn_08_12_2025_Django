if 10>2:
    print("inside if")
    print("2nd statament")
print("outside if")