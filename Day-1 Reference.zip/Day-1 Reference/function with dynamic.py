a= int(input('enter the value for a : '))
b=int(input('enter the value for b: '));

def add(x,y):
	return x+y
	
res =add(a,b);
print("sum of two numbers is : ",res)


def calculation():
	a=int(input('enter the value of a :'))
	b=int(input('enter the value of b : '))
	sum=a+b
	print("sum of two numbers is ",sum)


calculation()

