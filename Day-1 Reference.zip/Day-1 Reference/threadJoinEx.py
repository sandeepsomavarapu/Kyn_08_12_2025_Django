from threading import *
import time
def display():
    for i in range(10):
        print("child thread")
        time.sleep(4)
t=Thread(target=display)
t.start()
t.join()#t.join(5)wait for 5 seconds after that automatically will start
for i in range(10):
        print("Main thread")