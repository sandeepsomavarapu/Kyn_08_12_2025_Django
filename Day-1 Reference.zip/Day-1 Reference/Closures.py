#Nested Function
def sayHelllo(name):
	def display():
		print('hello',name)
	display()	
sayHelllo("sandeep")



#Closure
def greet():
    name="suresh"
    return lambda:"hi !"+name
message=greet()

print(message())
