from openpyxl import Workbook

wb = Workbook()
ws = wb.active
ws.oddHeader.center.text = "fffffffffffffffffff"
ws.oddHeader.center.size = 24
ws.oddHeader.center.font = "Tahoma,Bold"
ws.oddHeader.center.color = "CC3366"
ws.cell(row=1, column=1).value = 'hello'
wb.save('test.xlsx')