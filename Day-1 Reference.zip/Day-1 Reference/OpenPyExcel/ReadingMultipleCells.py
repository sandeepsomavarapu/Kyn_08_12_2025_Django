import openpyxl  
  
wb = openpyxl.load_workbook('marks.xlsx')  
  
sheet = wb.active  
print(tuple(sheet.rows))
print(tuple(sheet.columns))
# cell_range = wb['A1':'B1']
# print(cell_range)
