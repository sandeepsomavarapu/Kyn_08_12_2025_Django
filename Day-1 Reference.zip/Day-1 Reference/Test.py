print("welcome")
print(8/0)
print("remaining 1000 lines code")