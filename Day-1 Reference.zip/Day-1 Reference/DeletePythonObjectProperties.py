class Employee:  
    company = 'lti' 
    def __init__(self, name, age, gender):
        self.name = name
        self.age = age
        self.gender = gender
 
    def func_message(self):
        print(self.name + ' is learning Python Programming')
 
emp1 = Employee('John', 25, 'Male')
print(emp1.name)
print(emp1.age)
print(emp1.gender)
emp1.func_message()
 
del emp1.name        #name Object propertyDeleted
print(emp1.name)     #Error you will get
					 #print(emp1.name)
                     #AttributeError: 'Employee' object has no attribute 'name'