from threading import *
import threading

def display():
	for i in range(1,11):
		print("child thread",current_thread())

t=Thread(target=display)
t.start()#starting a thread 
t1=Thread(target=display)
t1.start()#starting a thread
for i in range(1,11):
		print("main thread",current_thread())