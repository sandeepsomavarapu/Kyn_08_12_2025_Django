import re
matchList=re.findall("[0-9]","a7b9c57kz") 
print(matchList)

updatedStr=re.sub("[a-z]","#","san7de12epS")
print(updatedStr)

updatedStr1=re.subn("[a-z]","#","san7de12epS")
print(updatedStr1[0])
print(updatedStr1[1])

splitex=re.split("\.","www.gmail.com")
print(splitex)
for word in splitex:
    print(word)
