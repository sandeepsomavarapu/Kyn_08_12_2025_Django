a=int(input("enter first number"))
b=int(input("enter second number"))
print("add of two number..",a+b)