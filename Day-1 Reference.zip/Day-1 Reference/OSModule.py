import os
print(os.name)
# os.mkdir("d:\\newpy")#create folder in the given path and name 
# print(os.getcwd()) #it rreturn current working directory
# print(os.listdir()) # list the directory files

# os.chdir("c:\\") 
# print(os.getcwd())
# os.rmdir("d:\\newpy")#it removes directory

file="python.txt"
# fileobj= open(file,"w")
# fileobj.write("welcome to hyderabad")
# fileobj.close()

# file1=open(file,'r')
# text=file1.read()
# print(text)

# file2=os.popen(file,'w')
# file2.write("second line")
# os.rename(file,"dell.txt")