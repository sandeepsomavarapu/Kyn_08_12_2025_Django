class Employee:
 
    value = 100
 
    def printValue(cls):
        print('The Value = %d' %cls.value) #using c syntax %d represent int variable
		print('the value is : ',cls.value)
 
Employee.printValue = classmethod(Employee.printValue)

Employee.printValue()