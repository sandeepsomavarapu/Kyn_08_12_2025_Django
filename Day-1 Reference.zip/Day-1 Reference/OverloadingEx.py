class TestOverload:
    def sum(self,a=None,b=None,c=None):
        if a!=None and b!=None and c!=None:
            print('sum of three numbers',a+b+c)
        elif a!=None and b!=None:
            print('sum of two numbers ',a+b)
        else:
            print('provide atleast two numbers ....')
        
        
        print("from m1 two-param method")
test =TestOverload()
test.sum(12,13,14)