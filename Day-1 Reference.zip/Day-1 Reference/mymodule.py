age=29
def f1():
	if __name__=='__main__':
		print(__name__)
		print("executed as a program")
	else:
		print(__name__)
		print("executed as a module")
f1()
#print(dir()) 

#print(__name__)
#__main__