import threading
print("welcome to VSCode Python",threading.current_thread().getName())