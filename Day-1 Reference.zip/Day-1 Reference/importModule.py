import mymodule

mymodule.sayHello(" using module")